export default function NotFound() {
  return (
    <div className="h-screen flex items-center justify-center">
      <h1 className="text-3xl">404 – Page non trouvée</h1>
    </div>
  );
}
